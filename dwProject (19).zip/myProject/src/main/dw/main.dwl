%dw 2.0
output application/json
---
payload.orders groupBy($.customerId)
pluck ((value, key) -> {
    "customerId": (key),
    "totalAmount": sum(value.amount),
    "highValueOrders": (value filter $.amount>1000).orderId,
    "customerCategory": if(sum(value.amount) > 5000) "PREMIUM" else "STANDARD"

}

)
%dw 2.0
output application/json
---
{
    "fullName" : payload.employee.firstName ++ " " ++ payload.employee.lastName,
    "maskedPan" : "XXXXXX" ++ payload.employee.pan[-5 to -2],
    "seniorSkills": (payload.employee.skills filter $.experience>3).name,
    "isSenior" : !isEmpty(payload.employee.skills filter $.experience>3) 
}

%dw 2.0
output application/json
---
payload groupBy ($.dept)
mapObject ((value, key) ->
(key) : value.name
 )

 
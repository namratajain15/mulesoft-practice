%dw 2.0
output application/json
---
payload map (
    $ mapObject(v,k) -> 
       (lower(k)) : (upper(v))
)
    

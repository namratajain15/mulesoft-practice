%dw 2.0
output application/json
---
payload flatMap((items) -> 
    items.employees filter ($.status == "active")
    map {
        "dept" : items.dept,
        "name" : $.name
    }
)
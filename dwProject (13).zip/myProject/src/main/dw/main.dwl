%dw 2.0
output application/json
---
payload filter($.status == "active") 
map {
    "id" : $.id,
    "fullname" : $.name
}
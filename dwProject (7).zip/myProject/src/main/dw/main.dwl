%dw 2.0
output application/json
---
payload map {
    "name" : $.name,
    "company": if ($.company is "abc" ) "xyz" else $.company
}
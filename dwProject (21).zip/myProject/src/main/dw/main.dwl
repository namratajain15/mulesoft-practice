%dw 2.0
output application/json
---
flatten(payload pluck((value,key) -> 
 value filter $.price>=500
 map{
     category : key,
     ("product_"++ $.id) : {
         "name" : $.name,
         "price" : $.price
     }
 }
))
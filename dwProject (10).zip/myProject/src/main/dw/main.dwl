%dw 2.0
output application/json
---
payload reduce(items , acc = {}) ->
    acc ++ (items.key) : items.value

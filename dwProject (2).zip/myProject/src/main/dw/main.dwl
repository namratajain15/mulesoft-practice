%dw 2.0
output application/json
---
payload groupBy($.customer)
pluck ((value, key) -> {
customer : key,
amount : sum(value.amount)
}
)
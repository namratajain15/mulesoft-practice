%dw 2.0
output application/json
var addresses = [
  { "id": 1, "city": "Pune" },
  { "id": 2, "city": "Mumbai" }
]
---
payload map (p) -> {
  "id" : p.id,
  "name" : p.name,
  "city" : (addresses filter ($.id == p.id)).city[0]
}
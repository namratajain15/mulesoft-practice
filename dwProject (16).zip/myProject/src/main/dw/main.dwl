%dw 2.0
output application/json
---
{
    "createdDate" : payload.createdDate as Date as String{format : "dd-MM-yyyy"}
}
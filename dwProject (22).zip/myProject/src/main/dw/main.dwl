%dw 2.0
output application/json
---
log(payload groupBy ($.dept))
mapObject ((value, key) -> 
{
(key) : {
 "count" : sizeOf(value),
 "totalSalary" : sum(value.salary)
}}
)
%dw 2.0
output application/json
---

"employees": 
 
        payload.employess.*employe filter($.dept == "Hr")
        map {
            employe : {
            id : $.id,
            name: $.name,
            dept : $.dept
            }
        }
        reduce(item, acc ={}) -> acc++ item
     
 

